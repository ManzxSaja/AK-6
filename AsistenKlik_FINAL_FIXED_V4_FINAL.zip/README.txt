ASISTEN KLIK — FINAL

ALUR:
1. Buka mutualan.com di Chrome.
2. Aktifkan Accessibility Service untuk Asisten Klik.
3. Tekan PLAY.
4. LIKE +10: tidak diklik -> refresh -> scan lagi.
5. FOLLOW +20: task dibuka -> TikTok -> hanya tombol persis Ikuti/Follow yang diklik.
6. Setelah TikTok berubah menjadi Mengikuti/Following atau Pesan/Message, aplikasi melakukan BACK sekali.
7. Setelah kembali ke Mutualan, refresh -> scan lagi.

PENTING:
- Aplikasi sengaja tidak mengklik "Mengikuti/Following" atau "Pesan/Message".
- Fokus otomatis dibatasi ke package Mutualan yang terdeteksi dan TikTok.
- Jika TikTok tidak terbuka atau Mutualan tidak kembali, automation berhenti tanpa mengklik aplikasi lain.
