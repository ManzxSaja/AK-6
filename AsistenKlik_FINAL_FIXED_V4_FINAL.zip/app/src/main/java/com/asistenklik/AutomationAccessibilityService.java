package com.asistenklik;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Locale;

public class AutomationAccessibilityService extends AccessibilityService {
    private static volatile boolean running = false;
    private static volatile AutomationAccessibilityService instance;

    private static final String TIKTOK_1 = "com.zhiliaoapp.musically";
    private static final String TIKTOK_2 = "com.ss.android.ugc.trill";

    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean busy = false;
    private boolean waitingTikTok = false;
    private boolean waitingTaskPage = false;
    private boolean followClicked = false;
    private String taskPackage = "";
    private long flowStartedAt = 0L;
    private int refreshAttempts = 0;

    public static void setRunning(boolean value) {
        running = value;
        MainActivity.log(value ? "PLAY — automation aktif" : "PAUSE — automation dijeda");
        MainActivity a = MainActivity.getInstance();
        if (a != null) a.refreshUi();

        // PLAY immediately resumes the current screen instead of waiting
        // for a new accessibility event.
        if (value && instance != null) {
            instance.handler.post(() -> instance.resumeFromCurrentScreen());
        }
    }

    public static boolean isRunning() {
        return running;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        MainActivity.log("Accessibility service terhubung");
        if (running) handler.post(this::resumeFromCurrentScreen);
    }

    private void resumeFromCurrentScreen() {
        if (!running) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        String pkg = getCurrentPackage();

        if (waitingTikTok && isTikTok(pkg)) {
            handleTikTok(root);
            return;
        }

        if (waitingTaskPage && isTaskPackage(pkg)) {
            waitForTaskPageNow(root);
            return;
        }

        // Never touch TikTok if there is no active TikTok flow.
        if (isTikTok(pkg)) return;

        if (taskPackage.isEmpty() && isMutualanPage(root)) {
            taskPackage = pkg;
            MainActivity.log("Mutualan terdeteksi: " + pkg);
        }

        if (isTaskPackage(pkg) && !busy) {
            if (findTask(root, "like", "10") != null) {
                startLikeFlow();
                return;
            }
            AccessibilityNodeInfo followTask = findTask(root, "follow", "20");
            if (followTask != null) startFollowFlow(followTask);
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!running) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        String pkg = event.getPackageName() == null ? "" : event.getPackageName().toString();

        // While waiting for TikTok, do nothing in every other application.
        if (waitingTikTok) {
            if (isTikTok(pkg)) handleTikTok(root);
            return;
        }

        // After a verified follow, accept only the original Mutualan package.
        if (waitingTaskPage) {
            if (isTaskPackage(pkg)) waitForTaskPageNow(root);
            return;
        }

        if (taskPackage.isEmpty() && isMutualanPage(root)) {
            taskPackage = pkg;
            MainActivity.log("Mutualan terdeteksi: " + pkg);
        }

        if (!isTaskPackage(pkg) || busy) return;

        // LIKE +10 is intentionally not clicked.
        if (findTask(root, "like", "10") != null) {
            startLikeFlow();
            return;
        }

        AccessibilityNodeInfo followTask = findTask(root, "follow", "20");
        if (followTask != null) startFollowFlow(followTask);
    }

    private boolean isMutualanPage(AccessibilityNodeInfo root) {
        return root != null &&
                (hasContains(root, "mutualan.com")
                        || findTask(root, "like", "10") != null
                        || findTask(root, "follow", "20") != null);
    }

    private void startLikeFlow() {
        if (busy) return;
        busy = true;
        refreshAttempts = 0;
        MainActivity.log("LIKE +10 terdeteksi — TIDAK diklik");
        delayThen(this::performLikeRefresh);
    }

    private void performLikeRefresh() {
        if (!running) return;

        if (!isTaskPackage(getCurrentPackage())) {
            handler.postDelayed(this::performLikeRefresh, 500);
            return;
        }

        refreshAttempts++;
        MainActivity.log("REFRESH Mutualan (" + refreshAttempts + ")");

        boolean sent = refreshMutualan();
        if (!sent && refreshAttempts < 3) {
            handler.postDelayed(this::performLikeRefresh, 700);
            return;
        }

        handler.postDelayed(() -> {
            if (!running) return;
            if (!isTaskPackage(getCurrentPackage())) {
                handler.postDelayed(this::performLikeRefresh, 700);
                return;
            }
            MainActivity.log("SCAN LAGI");
            resetFlow();
            resumeFromCurrentScreen();
        }, Math.max(1800, getDelayMs()));
    }

    private void startFollowFlow(AccessibilityNodeInfo taskNode) {
        if (busy) return;

        busy = true;
        waitingTikTok = false;
        waitingTaskPage = false;
        followClicked = false;
        flowStartedAt = System.currentTimeMillis();

        MainActivity.log("FOLLOW +20 terdeteksi");

        delayThen(() -> {
            if (!running) return;

            if (!isTaskPackage(getCurrentPackage())) {
                MainActivity.log("Batal buka task: bukan Mutualan");
                resetFlow();
                return;
            }

            AccessibilityNodeInfo root = getRootInActiveWindow();
            AccessibilityNodeInfo current = root == null ? null : findTask(root, "follow", "20");
            if (current == null) {
                MainActivity.log("FOLLOW +20 hilang — scan ulang");
                resetFlow();
                return;
            }

            // Limit ancestor search so a page-level control cannot be clicked.
            AccessibilityNodeInfo clickable = nearestTaskClickable(current);
            if (clickable == null ||
                    !clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                MainActivity.log("Klik task FOLLOW gagal — scan ulang");
                resetFlow();
                return;
            }

            waitingTikTok = true;
            MainActivity.log("Task FOLLOW dibuka — TUNGGU TikTok");
            waitForTikTok();
        });
    }

    private AccessibilityNodeInfo nearestTaskClickable(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        for (int i = 0; i < 5 && current != null; i++) {
            if (current.isVisibleToUser() && current.isClickable()) return current;
            current = current.getParent();
        }
        return null;
    }

    private void waitForTikTok() {
        if (!running) return;

        String pkg = getCurrentPackage();
        AccessibilityNodeInfo root = getRootInActiveWindow();

        if (isTikTok(pkg) && root != null) {
            handleTikTok(root);
            return;
        }

        // Do not press Back/Home/Recents while TikTok is opening.
        if (System.currentTimeMillis() - flowStartedAt >= 30000) {
            MainActivity.log("TikTok belum terbuka 30 detik — BATAL, tidak pindah app");
            resetFlow();
            return;
        }

        handler.postDelayed(this::waitForTikTok, 350);
    }

    private void handleTikTok(AccessibilityNodeInfo root) {
        if (!running || !isTikTok(getCurrentPackage())) return;

        // Following/Mengikuti is the only success signal after the click.
        if (followClicked && hasExactAny(root, "mengikuti", "following")) {
            MainActivity.log("FOLLOW BERHASIL — status MENGIKUTI");
            goBackToMutualan();
            return;
        }

        if (!followClicked) {
            AccessibilityNodeInfo followButton = findTikTokFollowButton(root);
            if (followButton != null && clickExactTikTokButton(followButton)) {
                followClicked = true;
                MainActivity.log("IKUTI TikTok diklik — tunggu konfirmasi");
                waitForFollowSuccess();
                return;
            }
        }

        if (System.currentTimeMillis() - flowStartedAt >= 30000) {
            // Critical safety rule: never Back if follow was not confirmed.
            MainActivity.log("FOLLOW belum terkonfirmasi — TIDAK BACK");
            resetFlow();
            return;
        }

        handler.postDelayed(() -> {
            if (!running) return;
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r != null && isTikTok(getCurrentPackage())) handleTikTok(r);
        }, 500);
    }

    private void waitForFollowSuccess() {
        if (!running) return;

        String pkg = getCurrentPackage();
        AccessibilityNodeInfo root = getRootInActiveWindow();

        // TikTok may still be loading. Never Back early.
        if (!isTikTok(pkg) || root == null) {
            handler.postDelayed(this::waitForFollowSuccess, 500);
            return;
        }

        if (hasExactAny(root, "mengikuti", "following")) {
            MainActivity.log("Konfirmasi FOLLOW diterima");
            goBackToMutualan();
            return;
        }

        if (System.currentTimeMillis() - flowStartedAt >= 30000) {
            MainActivity.log("FOLLOW belum terkonfirmasi — tetap di TikTok");
            resetFlow();
            return;
        }

        handler.postDelayed(this::waitForFollowSuccess, 700);
    }

    private void goBackToMutualan() {
        // Back is permitted ONLY after verified Following and ONLY from TikTok.
        if (!isTikTok(getCurrentPackage())) return;

        waitingTikTok = false;
        waitingTaskPage = true;
        followClicked = false;

        MainActivity.log("FOLLOW terverifikasi → kembali ke Mutualan");
        performGlobalAction(GLOBAL_ACTION_BACK);
        handler.postDelayed(this::waitForTaskPage, 700);
    }

    private void waitForTaskPage() {
        if (!running) return;

        String pkg = getCurrentPackage();
        AccessibilityNodeInfo root = getRootInActiveWindow();

        if (isTaskPackage(pkg) && root != null) {
            waitForTaskPageNow(root);
            return;
        }

        // Recover only by launching the already detected Mutualan package.
        // Never use Home or Recents.
        if (System.currentTimeMillis() - flowStartedAt >= 10000) {
            if (launchDetectedTaskApp()) {
                MainActivity.log("Mutualan belum kembali → buka kembali app Mutualan");
                handler.postDelayed(this::waitForTaskPage, 1200);
            } else {
                MainActivity.log("Gagal kembali ke Mutualan — berhenti aman");
                resetFlow();
            }
            return;
        }

        handler.postDelayed(this::waitForTaskPage, 500);
    }

    private void waitForTaskPageNow(AccessibilityNodeInfo root) {
        if (!isTaskPackage(getCurrentPackage())) return;

        if (!hasTaskMarker(root)) {
            handler.postDelayed(this::waitForTaskPage, 500);
            return;
        }

        waitingTaskPage = false;
        busy = true;
        refreshAttempts = 0;

        MainActivity.log("Mutualan kembali → refresh");
        handler.postDelayed(this::performLikeRefresh, Math.max(500, getDelayMs()));
    }

    private boolean launchDetectedTaskApp() {
        if (taskPackage.isEmpty()) return false;
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(taskPackage);
            if (intent == null) return false;
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean refreshMutualan() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !isTaskPackage(getCurrentPackage())) return false;

        // Prefer a real browser/WebView Refresh control if exposed.
        AccessibilityNodeInfo refresh = findVisibleExact(root, "refresh");
        if (refresh == null) refresh = findVisibleExact(root, "muat ulang");

        if (refresh != null && refresh.isEnabled()) {
            if (refresh.isClickable() &&
                    refresh.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true;
            }

            Rect r = new Rect();
            refresh.getBoundsInScreen(r);
            if (r.width() > 0 && r.height() > 0)
                return tapScreen(r.centerX(), r.centerY());
        }

        // Fallback: pull-to-refresh, but only inside the detected Mutualan package.
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        float x = w / 2f;

        Path p = new Path();
        p.moveTo(x, Math.max(120, h * 0.20f));
        p.lineTo(x, Math.min(h - 120, h * 0.68f));

        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(p, 0, 1000);

        return dispatchGesture(
                new GestureDescription.Builder().addStroke(stroke).build(),
                null, null);
    }

    private boolean tapScreen(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(p, 0, 80);

        return dispatchGesture(
                new GestureDescription.Builder().addStroke(stroke).build(),
                null, null);
    }

    private boolean hasTaskMarker(AccessibilityNodeInfo root) {
        return findTask(root, "like", "10") != null
                || findTask(root, "follow", "20") != null
                || hasContains(root, "mutualan.com");
    }

    private boolean isTaskPackage(String pkg) {
        return pkg != null && !pkg.isEmpty()
                && !taskPackage.isEmpty() && pkg.equals(taskPackage);
    }

    private boolean isTikTok(String pkg) {
        return TIKTOK_1.equals(pkg) || TIKTOK_2.equals(pkg);
    }

    private String getCurrentPackage() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null && root.getPackageName() != null)
            return root.getPackageName().toString();
        return "";
    }

    private void resetFlow() {
        busy = false;
        waitingTikTok = false;
        waitingTaskPage = false;
        followClicked = false;
        flowStartedAt = 0L;
        refreshAttempts = 0;
    }

    private AccessibilityNodeInfo findTask(AccessibilityNodeInfo root, String word, String number) {
        if (root == null) return null;

        String text = normalize(nodeText(root));
        String w = normalize(word);
        String n = normalize(number);

        if (text.contains(w + " +" + n) || text.contains(w + " " + n)
                || text.contains(w + n)) return root;

        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found = findTask(root.getChild(i), word, number);
            if (found != null) return found;
        }
        return null;
    }

    private AccessibilityNodeInfo findTikTokFollowButton(AccessibilityNodeInfo root) {
        if (root == null) return null;
        if (isVisibleNode(root) && isExactFollowText(root)) return root;

        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found = findTikTokFollowButton(root.getChild(i));
            if (found != null) return found;
        }
        return null;
    }

    private boolean isExactFollowText(AccessibilityNodeInfo node) {
        if (node == null || !node.isEnabled()) return false;

        String t = node.getText() == null ? "" : normalize(node.getText().toString());
        String d = node.getContentDescription() == null ? "" :
                normalize(node.getContentDescription().toString());

        if (isFollowingState(t) || isFollowingState(d)) return false;

        return "ikuti".equals(t) || "follow".equals(t)
                || "ikuti".equals(d) || "follow".equals(d);
    }

    private boolean isVisibleNode(AccessibilityNodeInfo node) {
        if (node == null || !node.isVisibleToUser()) return false;

        Rect r = new Rect();
        node.getBoundsInScreen(r);

        return r.width() > 0 && r.height() > 0
                && r.left >= 0 && r.top >= 0;
    }

    private boolean clickExactTikTokButton(AccessibilityNodeInfo node) {
        if (!isVisibleNode(node) || !isExactFollowText(node)) return false;

        Rect r = new Rect();
        node.getBoundsInScreen(r);

        return tapScreen(r.centerX(), r.centerY());
    }

    private boolean isFollowingState(String text) {
        return "mengikuti".equals(text) || "following".equals(text);
    }

    private boolean hasExactAny(AccessibilityNodeInfo root, String... targets) {
        for (String target : targets)
            if (findVisibleExact(root, target) != null) return true;
        return false;
    }

    private AccessibilityNodeInfo findVisibleExact(AccessibilityNodeInfo root, String target) {
        if (root == null) return null;

        String wanted = normalize(target);

        if (isVisibleNode(root)) {
            CharSequence text = root.getText();
            CharSequence desc = root.getContentDescription();

            if (text != null && normalize(text.toString()).equals(wanted)) return root;
            if (desc != null && normalize(desc.toString()).equals(wanted)) return root;
        }

        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found = findVisibleExact(root.getChild(i), target);
            if (found != null) return found;
        }
        return null;
    }

    private boolean hasContains(AccessibilityNodeInfo root, String target) {
        if (root == null) return false;

        if (normalize(nodeText(root)).contains(normalize(target))) return true;

        for (int i = 0; i < root.getChildCount(); i++)
            if (hasContains(root.getChild(i), target)) return true;

        return false;
    }

    private String nodeText(AccessibilityNodeInfo node) {
        if (node == null) return "";

        StringBuilder s = new StringBuilder();

        if (node.getText() != null) s.append(node.getText()).append(' ');
        if (node.getContentDescription() != null) s.append(node.getContentDescription());

        return s.toString();
    }

    private String normalize(String s) {
        return s == null ? "" :
                s.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
    }

    private void delayThen(Runnable r) {
        handler.postDelayed(r, getDelayMs());
    }

    private long getDelayMs() {
        MainActivity a = MainActivity.getInstance();
        if (a != null) return Math.max(300, a.getDelayMs());
        return 3000;
    }

    @Override
    public void onInterrupt() {
        // Keep state so a temporary accessibility interruption does not
        // destroy the current Play/Pause flow.
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        running = false;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
