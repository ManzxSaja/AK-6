package com.asistenklik;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Locale;

/**
 * Strict automation:
 * Mutualan (Chrome) -> TikTok -> Mutualan.
 *
 * LIKE +10: never click the task. Wait -> refresh -> scan again.
 * FOLLOW +20: click only the task -> wait for TikTok -> wait until the
 * exact Follow button is available -> tap it -> verify Following -> Back once.
 *
 * No Home / Recents actions are used.
 */
public class AutomationAccessibilityService extends AccessibilityService {
    private static volatile boolean running = false;
    private static AutomationAccessibilityService instance;

    private static final String TIKTOK_1 = "com.zhiliaoapp.musically";
    private static final String TIKTOK_2 = "com.ss.android.ugc.trill";
    private static final String CHROME = "com.android.chrome";

    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean busy = false;
    private boolean waitingTikTok = false;
    private boolean waitingTaskPage = false;
    private boolean followClicked = false;
    private int followAttempts = 0;
    private int refreshAttempts = 0;

    private String taskPackage = "";
    private long flowStartedAt = 0L;
    private long stateToken = 0L;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        MainActivity.log("Accessibility Service siap");
    }

    public static void setRunning(boolean value) {
        running = value;

        AutomationAccessibilityService s = instance;
        if (s != null) {
            if (!value) {
                s.stateToken++;
                s.handler.removeCallbacksAndMessages(null);
                s.resetFlow();
                MainActivity.log("PAUSE — semua timer dan aksi dibatalkan");
            } else {
                s.stateToken++;
                s.handler.removeCallbacksAndMessages(null);
                s.resetFlow();
                MainActivity.log("PLAY — mulai scan dari Mutualan");
                s.scheduleScan(250);
            }
        } else {
            MainActivity.log(value ? "PLAY — menunggu Accessibility Service" :
                    "PAUSE — automation dihentikan");
        }

        MainActivity a = MainActivity.getInstance();
        if (a != null) a.refreshUi();
    }

    public static boolean isRunning() {
        return running;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!running || busy) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        String pkg = event.getPackageName() == null ? "" :
                event.getPackageName().toString();

        if (waitingTikTok) {
            if (isTikTok(pkg)) handleTikTok(root);
            return;
        }

        if (waitingTaskPage) {
            if (isTaskPackage(pkg)) handleTaskPage(root);
            return;
        }

        if (taskPackage.isEmpty() && isMutualanPage(root, pkg)) {
            taskPackage = pkg;
            MainActivity.log("Mutualan terdeteksi: " + pkg);
        }

        if (!isTaskPackage(pkg)) return;

        AccessibilityNodeInfo like = findTask(root, "like", "10");
        if (like != null) {
            startLikeFlow();
            return;
        }

        AccessibilityNodeInfo follow = findTask(root, "follow", "20");
        if (follow != null) {
            startFollowFlow(follow);
        }
    }

    private void scheduleScan(long delay) {
        final long token = stateToken;
        handler.postDelayed(() -> {
            if (!running || token != stateToken) return;

            AccessibilityNodeInfo root = getRootInActiveWindow();
            String pkg = getCurrentPackage();

            if (root != null && isTaskPackage(pkg)) {
                scanMutualan(root);
            }
        }, delay);
    }

    private void scanMutualan(AccessibilityNodeInfo root) {
        if (!running || busy || root == null) return;

        if (taskPackage.isEmpty()) {
            String pkg = getCurrentPackage();
            if (isMutualanPage(root, pkg)) taskPackage = pkg;
        }

        if (!isTaskPackage(getCurrentPackage())) return;

        if (findTask(root, "like", "10") != null) {
            startLikeFlow();
            return;
        }

        AccessibilityNodeInfo follow = findTask(root, "follow", "20");
        if (follow != null) startFollowFlow(follow);
    }

    private boolean isMutualanPage(AccessibilityNodeInfo root, String pkg) {
        if (root == null || pkg == null || pkg.isEmpty()) return false;
        return hasContains(root, "mutualan.com")
                || findTask(root, "like", "10") != null
                || findTask(root, "follow", "20") != null;
    }

    // ------------------------------------------------------------
    // LIKE
    // ------------------------------------------------------------

    private void startLikeFlow() {
        if (busy || !running) return;

        busy = true;
        refreshAttempts = 0;

        MainActivity.log("LIKE +10 terdeteksi — TIDAK diklik");

        final long token = stateToken;
        handler.postDelayed(() -> {
            if (!running || token != stateToken) return;
            refreshMutualan(token);
        }, getDelayMs());
    }

    private void refreshMutualan(long token) {
        if (!running || token != stateToken) return;

        String pkg = getCurrentPackage();

        if (!isTaskPackage(pkg)) {
            MainActivity.log("Bukan Mutualan — menunggu kembali");
            handler.postDelayed(() -> refreshMutualan(token), 500);
            return;
        }

        refreshAttempts++;
        MainActivity.log("REFRESH Mutualan #" + refreshAttempts);

        boolean refreshed = clickBrowserReload();

        if (!refreshed) {
            refreshed = refreshGesture();
        }

        if (!refreshed) {
            MainActivity.log("Refresh gagal dikirim — coba lagi");
            handler.postDelayed(() -> refreshMutualan(token), 1200);
            return;
        }

        final int attempt = refreshAttempts;

        handler.postDelayed(() -> {
            if (!running || token != stateToken) return;

            if (!isTaskPackage(getCurrentPackage())) {
                handler.postDelayed(() -> refreshMutualan(token), 700);
                return;
            }

            MainActivity.log("Refresh selesai → SCAN LAGI");
            resetFlow();
            scheduleScan(500);
        }, Math.max(1800, getDelayMs()));
    }

    /**
     * Chrome exposes the toolbar reload action to Accessibility on many
     * versions. Prefer this over a blind swipe because it is deterministic.
     */
    private boolean clickBrowserReload() {
        if (!CHROME.equals(taskPackage)) return false;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !CHROME.equals(getCurrentPackage())) return false;

        AccessibilityNodeInfo reload = findExactDescription(root,
                "reload", "muat ulang", "muat semula");

        if (reload == null) return false;
        if (!reload.isEnabled() || !reload.isVisibleToUser()) return false;

        if (reload.isClickable()) {
            boolean ok = reload.performAction(
                    AccessibilityNodeInfo.ACTION_CLICK);
            if (ok) {
                MainActivity.log("Chrome Reload diklik");
                return true;
            }
        }

        Rect r = new Rect();
        reload.getBoundsInScreen(r);

        if (r.width() <= 0 || r.height() <= 0) return false;

        return tapRect(r);
    }

    private boolean refreshGesture() {
        if (!isTaskPackage(getCurrentPackage())) return false;

        AccessibilityNodeInfo root = getRootInActiveWindow();

        // Try to bring the web page to the top first. Pull-to-refresh normally
        // works only when the scroll position is already at the top.
        if (root != null) {
            for (int i = 0; i < 4; i++) {
                try {
                    root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
                } catch (Exception ignored) {
                }
            }
        }

        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;

        float x = w / 2f;
        float startY = Math.max(110, h * 0.12f);
        float endY = Math.min(h * 0.62f, h - 180);

        Path p = new Path();
        p.moveTo(x, startY);
        p.lineTo(x, endY);

        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(p, 0, 1000);

        return dispatchGesture(
                new GestureDescription.Builder()
                        .addStroke(stroke)
                        .build(),
                null,
                null);
    }

    // ------------------------------------------------------------
    // FOLLOW
    // ------------------------------------------------------------

    private void startFollowFlow(AccessibilityNodeInfo taskNode) {
        if (busy || !running) return;

        busy = true;
        waitingTikTok = false;
        waitingTaskPage = false;
        followClicked = false;
        followAttempts = 0;
        flowStartedAt = System.currentTimeMillis();

        MainActivity.log("FOLLOW +20 terdeteksi");

        final long token = stateToken;

        handler.postDelayed(() -> {
            if (!running || token != stateToken) return;

            AccessibilityNodeInfo root = getRootInActiveWindow();

            if (root == null || !isTaskPackage(getCurrentPackage())) {
                MainActivity.log("Mutualan tidak aktif — batal tanpa klik");
                resetFlow();
                scheduleScan(800);
                return;
            }

            AccessibilityNodeInfo current =
                    findTask(root, "follow", "20");

            if (current == null) current = taskNode;

            if (!clickTaskSafely(current)) {
                MainActivity.log("Task FOLLOW gagal diklik — scan ulang");
                resetFlow();
                scheduleScan(1000);
                return;
            }

            MainActivity.log("FOLLOW task diklik → TUNGGU TIKTOK");

            waitingTikTok = true;

            handler.postDelayed(() -> {
                if (!running || token != stateToken) return;
                waitForTikTok(token);
            }, 300);
        }, getDelayMs());
    }

    private boolean clickTaskSafely(AccessibilityNodeInfo node) {
        if (node == null) return false;

        Rect childRect = new Rect();
        node.getBoundsInScreen(childRect);

        if (childRect.width() <= 0 || childRect.height() <= 0) {
            return false;
        }

        AccessibilityNodeInfo clickable = findSmallClickableAncestor(node);

        if (clickable != null) {
            Rect parentRect = new Rect();
            clickable.getBoundsInScreen(parentRect);

            long childArea = (long) childRect.width() * childRect.height();
            long parentArea = (long) parentRect.width() * parentRect.height();

            // Reject giant page/container click targets.
            if (parentArea > 0 && parentArea <= childArea * 20L) {
                if (clickable.performAction(
                        AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true;
                }
            }
        }

        // Fallback: tap the actual task node, not its giant parent.
        return tapRect(childRect);
    }

    private AccessibilityNodeInfo findSmallClickableAncestor(
            AccessibilityNodeInfo node) {

        AccessibilityNodeInfo current = node;

        for (int i = 0; i < 8 && current != null; i++) {
            if (current.isClickable() && current.isVisibleToUser()) {
                return current;
            }
            current = current.getParent();
        }

        return null;
    }

    private void waitForTikTok(long token) {
        if (!running || token != stateToken) return;

        if (!waitingTikTok) return;

        String pkg = getCurrentPackage();
        AccessibilityNodeInfo root = getRootInActiveWindow();

        if (isTikTok(pkg) && root != null) {
            MainActivity.log("TikTok aktif → TUNGGU HALAMAN SELESAI LOAD");
            waitForFollowButton(token);
            return;
        }

        // NEVER BACK because TikTok is still loading.
        handler.postDelayed(() -> waitForTikTok(token), 500);
    }

    private void waitForFollowButton(long token) {
        if (!running || token != stateToken) return;
        if (!waitingTikTok) return;

        if (!isTikTok(getCurrentPackage())) {
            // If TikTok disappears unexpectedly, wait for it to return.
            handler.postDelayed(() -> waitForTikTok(token), 500);
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();

        if (root == null) {
            handler.postDelayed(() -> waitForFollowButton(token), 500);
            return;
        }

        // If follow was clicked, ONLY Following/Mengikuti confirms success.
        if (followClicked) {
            if (hasExactAny(root, "mengikuti", "following")) {
                MainActivity.log("STATUS MENGIKUTI → BACK ke Mutualan");
                finishTikTok(token);
                return;
            }

            // If the UI has not changed yet, keep waiting.
            handler.postDelayed(() -> waitForFollowButton(token), 600);
            return;
        }

        AccessibilityNodeInfo follow =
                findBestTikTokFollowButton(root);

        if (follow != null) {
            followAttempts++;

            if (tapExactNode(follow)) {
                followClicked = true;
                MainActivity.log(
                        "IKUTI TikTok diklik — VERIFIKASI STATUS");

                handler.postDelayed(
                        () -> waitForFollowButton(token),
                        Math.max(1200, getDelayMs()));
                return;
            }

            if (followAttempts < 5) {
                handler.postDelayed(
                        () -> waitForFollowButton(token), 700);
                return;
            }
        }

        // NO timeout / NO BACK here.
        // TikTok can take longer to load. Keep scanning.
        handler.postDelayed(() -> waitForFollowButton(token), 700);
    }

    private AccessibilityNodeInfo findBestTikTokFollowButton(
            AccessibilityNodeInfo root) {

        if (root == null) return null;

        AccessibilityNodeInfo[] best = new AccessibilityNodeInfo[1];

        findFollowRecursive(root, best);

        return best[0];
    }

    private void findFollowRecursive(
            AccessibilityNodeInfo node,
            AccessibilityNodeInfo[] best) {

        if (node == null || best[0] != null) {
            // Still no need to inspect after finding first valid target.
            return;
        }

        if (isVisibleNode(node) && isExactFollowText(node)) {
            Rect r = new Rect();
            node.getBoundsInScreen(r);

            // Ignore impossible / tiny nodes.
            if (r.width() >= 30 && r.height() >= 20) {
                best[0] = node;
                return;
            }
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            findFollowRecursive(node.getChild(i), best);
            if (best[0] != null) return;
        }
    }

    private boolean isExactFollowText(AccessibilityNodeInfo node) {
        if (node == null || !node.isEnabled()) return false;

        String t = node.getText() == null ? "" :
                normalize(node.getText().toString());

        String d = node.getContentDescription() == null ? "" :
                normalize(node.getContentDescription().toString());

        if (isCompletedFollow(t) || isCompletedFollow(d)) return false;

        return "ikuti".equals(t)
                || "follow".equals(t)
                || "ikuti".equals(d)
                || "follow".equals(d);
    }

    private boolean isCompletedFollow(String text) {
        return "mengikuti".equals(text)
                || "following".equals(text);
    }

    private void finishTikTok(long token) {
        if (!running || token != stateToken) return;
        if (!isTikTok(getCurrentPackage())) return;

        waitingTikTok = false;
        waitingTaskPage = true;

        followClicked = false;

        // Exactly one Back, ONLY from TikTok.
        performGlobalAction(GLOBAL_ACTION_BACK);
        MainActivity.log("BACK sekali dari TikTok → tunggu Mutualan");

        handler.postDelayed(
                () -> waitForTaskPage(token),
                700);
    }

    private void waitForTaskPage(long token) {
        if (!running || token != stateToken) return;
        if (!waitingTaskPage) return;

        String pkg = getCurrentPackage();

        if (isTaskPackage(pkg)) {
            AccessibilityNodeInfo root = getRootInActiveWindow();

            if (root != null && hasTaskMarker(root)) {
                MainActivity.log("Mutualan kembali");
                waitingTaskPage = false;

                final long t = stateToken;

                handler.postDelayed(() -> {
                    if (!running || t != stateToken) return;

                    MainActivity.log("Delay selesai → REFRESH Mutualan");
                    refreshAttempts = 0;
                    busy = true;
                    refreshMutualan(t);
                }, getDelayMs());

                return;
            }
        }

        // Never press Back/Home/Recents.
        handler.postDelayed(() -> waitForTaskPage(token), 500);
    }

    private void handleTaskPage(AccessibilityNodeInfo root) {
        if (!running || root == null) return;
        if (!isTaskPackage(getCurrentPackage())) return;

        waitingTaskPage = false;
        busy = true;

        final long token = stateToken;

        handler.postDelayed(() -> {
            if (!running || token != stateToken) return;
            refreshAttempts = 0;
            refreshMutualan(token);
        }, getDelayMs());
    }

    // ------------------------------------------------------------
    // Accessibility helpers
    // ------------------------------------------------------------

    private AccessibilityNodeInfo findTask(
            AccessibilityNodeInfo root,
            String word,
            String number) {

        if (root == null) return null;

        String text = normalize(nodeText(root));
        String w = normalize(word);
        String n = normalize(number);

        if (text.contains(w + " +" + n)
                || text.contains(w + " " + n)
                || text.contains(w + n)) {
            return root;
        }

        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found =
                    findTask(root.getChild(i), word, number);

            if (found != null) return found;
        }

        return null;
    }

    private boolean hasTaskMarker(AccessibilityNodeInfo root) {
        return findTask(root, "like", "10") != null
                || findTask(root, "follow", "20") != null
                || hasContains(root, "mutualan.com");
    }

    private AccessibilityNodeInfo findExactDescription(
            AccessibilityNodeInfo root,
            String... targets) {

        if (root == null) return null;

        CharSequence desc = root.getContentDescription();

        if (desc != null) {
            String value = normalize(desc.toString());

            for (String target : targets) {
                if (value.equals(normalize(target))) {
                    return root;
                }
            }
        }

        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found =
                    findExactDescription(root.getChild(i), targets);

            if (found != null) return found;
        }

        return null;
    }

    private boolean hasExactAny(
            AccessibilityNodeInfo root,
            String... targets) {

        for (String target : targets) {
            if (findVisibleExact(root, target) != null) return true;
        }

        return false;
    }

    private AccessibilityNodeInfo findVisibleExact(
            AccessibilityNodeInfo root,
            String target) {

        if (root == null) return null;

        String wanted = normalize(target);

        CharSequence text = root.getText();
        CharSequence desc = root.getContentDescription();

        if (isVisibleNode(root)) {
            if (text != null
                    && normalize(text.toString()).equals(wanted)) {
                return root;
            }

            if (desc != null
                    && normalize(desc.toString()).equals(wanted)) {
                return root;
            }
        }

        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found =
                    findVisibleExact(root.getChild(i), target);

            if (found != null) return found;
        }

        return null;
    }

    private boolean tapExactNode(AccessibilityNodeInfo node) {
        if (!isVisibleNode(node)) return false;
        if (!isExactFollowText(node)) return false;

        Rect r = new Rect();
        node.getBoundsInScreen(r);

        return tapRect(r);
    }

    private boolean tapRect(Rect r) {
        if (r == null || r.width() <= 0 || r.height() <= 0) {
            return false;
        }

        float x = r.centerX();
        float y = r.centerY();

        Path path = new Path();
        path.moveTo(x, y);

        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(
                        path, 0, 100);

        return dispatchGesture(
                new GestureDescription.Builder()
                        .addStroke(stroke)
                        .build(),
                null,
                null);
    }

    private boolean isVisibleNode(AccessibilityNodeInfo node) {
        if (node == null || !node.isVisibleToUser()) return false;

        Rect r = new Rect();
        node.getBoundsInScreen(r);

        return r.width() > 0
                && r.height() > 0
                && r.left >= 0
                && r.top >= 0;
    }

    private boolean hasContains(
            AccessibilityNodeInfo root,
            String target) {

        if (root == null) return false;

        if (normalize(nodeText(root))
                .contains(normalize(target))) {
            return true;
        }

        for (int i = 0; i < root.getChildCount(); i++) {
            if (hasContains(root.getChild(i), target)) {
                return true;
            }
        }

        return false;
    }

    private String nodeText(AccessibilityNodeInfo node) {
        if (node == null) return "";

        StringBuilder s = new StringBuilder();

        if (node.getText() != null) {
            s.append(node.getText()).append(' ');
        }

        if (node.getContentDescription() != null) {
            s.append(node.getContentDescription());
        }

        return s.toString();
    }

    private String normalize(String s) {
        return s == null ? "" :
                s.toLowerCase(Locale.ROOT)
                        .replaceAll("\\s+", " ")
                        .trim();
    }

    private String getCurrentPackage() {
        AccessibilityNodeInfo root = getRootInActiveWindow();

        if (root != null && root.getPackageName() != null) {
            return root.getPackageName().toString();
        }

        return "";
    }

    private boolean isTaskPackage(String pkg) {
        return pkg != null
                && !pkg.isEmpty()
                && !taskPackage.isEmpty()
                && pkg.equals(taskPackage);
    }

    private boolean isTikTok(String pkg) {
        return TIKTOK_1.equals(pkg) || TIKTOK_2.equals(pkg);
    }

    private long getDelayMs() {
        MainActivity a = MainActivity.getInstance();

        if (a != null) {
            return Math.max(300, a.getDelayMs());
        }

        return 3000;
    }

    private void resetFlow() {
        busy = false;
        waitingTikTok = false;
        waitingTaskPage = false;
        followClicked = false;
        followAttempts = 0;
        refreshAttempts = 0;
        flowStartedAt = 0L;
    }

    @Override
    public void onInterrupt() {
        stateToken++;
        running = false;
        handler.removeCallbacksAndMessages(null);
        resetFlow();
    }

    @Override
    public void onDestroy() {
        stateToken++;
        running = false;
        handler.removeCallbacksAndMessages(null);

        if (instance == this) {
            instance = null;
        }

        super.onDestroy();
    }
}
