ASISTEN KLIK V4

Alur:
Mutualan.com -> TikTok -> Follow -> verifikasi Mengikuti -> Back -> Mutualan -> Refresh -> Scan lagi.

LIKE +10:
Tidak diklik. Delay -> refresh -> scan lagi.

FOLLOW +20:
Klik task -> tunggu TikTok tanpa timeout -> cari tombol exact Ikuti/Follow -> tap -> tunggu Mengikuti/Following -> Back sekali.

PAUSE:
Membatalkan seluruh timer/aksi yang tertunda.

PLAY:
Memulai ulang scan dari halaman Mutualan.

GitHub:
.github/workflows/build-apk.yml
